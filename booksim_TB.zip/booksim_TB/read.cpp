#include<iostream>
#include <fstream>
#include <string.h>
#include<stdlib.h>
#define MAX 4
using namespace std;


int count =0, i =0;
int source_dest[MAX][8];

int main(){

 	char *token, *nxttok, read[100];
	ifstream confile;
	confile.open("Config.txt");                                                                       //Reading the Configuration File

	if (!confile){
		cout << "Couldn't Read the Configuration File" << endl;
		cout << "ENDING FURTHER PROCESSING OF FILE...................................." << endl;
		return(0);
	}

   while (confile){
    	memset(read,sizeof(read), '\0');
      	confile.getline(read, 100, '\n');
      cout<<read<<endl;
     	if(count < 4){
   	    if(!isalpha(read[0])){
     		token = strtok(read, " ");
     		while(token != NULL){  
       			token = strtok(NULL, ",");
       			cout<<token<<endl;
       			source_dest[count][i] = atoi(token);
                        i++;
     		}
   	  count++;
  	   }
 	}
  }

return(0);
}
