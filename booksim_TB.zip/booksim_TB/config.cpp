#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string.h>
using namespace std;

int main(){

struct{
int src;
int dest;
} TL_SRC_DEST[20];
int index  = 0;

ifstream fin;
fin.open("config.txt");
char read_arr[10], *token;

	while((fin>>read_arr)){
		token = strtok(read_arr, ":");
		TL_SRC_DEST[index].src = atoi(token);
		token = strtok(NULL,":");
		TL_SRC_DEST[index].dest = atoi(token);
		index++;
	}


for(int i=0; i<index;i++){
 cout<<" Src = "<<TL_SRC_DEST[i].src<<" Dest = "<<TL_SRC_DEST[i].dest<<endl;
}
fin.close();
return 0;
}
