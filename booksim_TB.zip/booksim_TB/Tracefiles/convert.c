#include<stdio.h>
#include<string.h>
#include<stdlib.h>

unsigned int foo(const char * s) {
 unsigned int result = 0;
 int c ;
 if ('0' == *s && 'x' == *(s+1)) { s+=2;
  while (*s) {
   result = result << 4;
   if (c=(*s-'0'),(c>=0 && c <=9)) result|=c;
   else if (c=(*s-'A'),(c>=0 && c <=5)) result|=(c+10);
   else if (c=(*s-'a'),(c>=0 && c <=5)) result|=(c+10);
   else break;
   ++s;
  }
 }
 return result;
}


void main(int argc, char **argv)
{
//int x=foo("0x169C0");
// int y=x>>13;

 int y, time, source, nbytes,len;
 char *op;
 FILE *fp, *fp1;
 
 fp = fopen(argv[1], "r");
 fp1 = fopen(argv[2], "w");
 if(fp == NULL){
   printf("\nCouldn't Open the file\n");
   return;
 }

 while(fscanf(fp, "%d %x %s %d", &time, &y, op, &source) == 4){
        int set = y & 0x001fffc0;
        int set1 = set>>6;
        int dest = set1/512;
        if(source != dest)
    	   fprintf(fp1, "%d\t%d\t%d\n" ,time,  source, dest);
  }

 
    fclose(fp);
    fclose(fp1);
}
