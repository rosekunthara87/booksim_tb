// $Id$

/*
Copyright (c) 2007-2009, Trustees of The Leland Stanford Junior University
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice, this 
list of conditions and the following disclaimer in the documentation and/or 
other materials provided with the distribution.
Neither the name of the Stanford University nor the names of its contributors 
may be used to endorse or promote products derived from this software without 
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "iq_router_base.hpp"
#include<queue>
#include<vector>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <cassert>
#include<math.h>
#include "globals.hpp"
#include "random_utils.hpp"
#include "vc.hpp"
#include "outputset.hpp"
#include "buffer_state.hpp"

IQRouterBase::IQRouterBase( const Configuration& config,
		    Module *parent, const string & name, int id,
		    int inputs, int outputs )
  : Router( config, parent, name, id, inputs, outputs ), 
    bufferMonitor(inputs), 
    switchMonitor(inputs, outputs) 
{
	  ostringstream vc_name;
	  
	  _vcs         = config.GetInt( "num_vcs" ); 
	  _vc_size     = config.GetInt( "vc_buf_size" );// depth of a vc

	  _routing_delay    = config.GetInt( "routing_delay" );
	  _vc_alloc_delay   = config.GetInt( "vc_alloc_delay" );
	  _sw_alloc_delay   = config.GetInt( "sw_alloc_delay" );
	  		// cout<<_routing_delay<<"   "<< _vc_alloc_delay<<"     "<< _sw_alloc_delay<<endl; // added John
	  		//cout<<_vcs<<"     "<< _vc_size<<endl; // added John
	  // Routing function extracted
	  _rf = GetRoutingFunction( config );
			 //cout<<"_rf ="<<_rf<<endl; // added John
	  // Alloc VC's
	  _vc.resize(_inputs);
	 		//	cout<<"_vcinputs ="<<_vc<<endl; // added John
  	 for ( int i = 0; i < _inputs; ++i )
	 {
	    	_vc[i].resize(_vcs); // for every port, for every VC
	    	for (int j = 0; j < _vcs; ++j )
		{
	      		_vc[i][j] = new VC(config, _outputs);
	      		vc_name << "vc_i" << i << "_v" << j;
	      		_vc[i][j]->SetName( this, vc_name.str( ) );
	      		vc_name.str("");
  		}
  	}

  	// Alloc next VCs' buffer state
	_next_vcs.resize(_outputs);
	for (int j = 0; j < _outputs; ++j)
	{
	    	_next_vcs[j] = new BufferState( config );
	    	vc_name << "next_vc_o" << j;
	    	_next_vcs[j]->SetName( this, vc_name.str( ) );
	    	vc_name.str("");
  	}

	  // Alloc pipelines (to simulate processing/transmission delays)
	  _crossbar_pipe = 
	    new PipelineFIFO<Flit>( this, "crossbar_pipeline", _outputs*_output_speedup, 
				    _st_prepare_delay + _st_final_delay );

	  _credit_pipe =
	    new PipelineFIFO<Credit>( this, "credit_pipeline", _inputs,
				      _credit_delay );

	  // Input and output queues
	  //_input_buffer.resize(_inputs); 
	  _output_buffer.resize(_outputs); 

	  _in_cred_buffer.resize(_inputs); 
	  //_out_cred_buffer.resize(_outputs);

	  // Switch configuration (when held for multiple cycles)
	  _hold_switch_for_packet = config.GetInt( "hold_switch_for_packet" );
	  _switch_hold_in.resize(_inputs*_input_speedup, -1);
	  _switch_hold_out.resize(_outputs*_output_speedup, -1);
	  _switch_hold_vc.resize(_inputs*_input_speedup, -1);

	  _received_flits.resize(_inputs);
	  _sent_flits.resize(_outputs);
	  ResetFlitStats();
}

IQRouterBase::~IQRouterBase( )
{
  if(_print_activity){
    cout << Name() << ".bufferMonitor:" << endl ; 
    cout << bufferMonitor << endl ;
    
    cout << Name() << ".switchMonitor:" << endl ; 
    cout << "Inputs=" << _inputs ;
    cout << "Outputs=" << _outputs ;
    cout << switchMonitor << endl ;
  }

  for ( int i = 0; i < _inputs; ++i )
    for (int j = 0; j < _vcs; ++j )
      delete _vc[i][j];
  
  for (int j = 0; j < _outputs; ++j)
    delete _next_vcs[j];

  delete _crossbar_pipe;
  delete _credit_pipe;

}
  
void IQRouterBase::ReadInputs( )
{
  	_ReceiveFlits( );  // go down to see code
  	_ReceiveCredits( );// go down to see code
}

void IQRouterBase::InternalStep( )
{

      
     //Dipika: For number of cycles spent in router, save the present cycle
     
	  //  _InputQueuing( ); not needed
	_Route( );   // go down to see code
	
	//cout<<"Current Router calling Alloc: "<<this->GetID()<<endl;
	_Alloc( );   // goto IQRouterBaseline-->Alloc();
	 
	for ( int input = 0; input < _inputs; ++input )
	{
		for ( int vc = 0; vc < _vcs; ++vc )
		{
	      		_vc[input][vc]->AdvanceTime( );
	    	}
	}

	_crossbar_pipe->Advance( );
	_credit_pipe->Advance( );
 
  
     //Dipika: For number of cycles spent in router, subtract the present cycle from the saved cycle
     
	_OutputQueuing( );
}

void IQRouterBase::WriteOutputs( )
{
  	_SendFlits( );	 // go down to see code
  	_SendCredits( ); // go down to see code
}

void IQRouterBase::_ReceiveFlits( )
{
	Flit *f;
	ofstream ofile;
	int ret;
        ofile.open("track.txt",ios::app);
	 // _inputs stands for number of input port for a router (here it is 5 )
	for ( int input = 0; input < _inputs; ++input ) // do for each input port...
	{ 
	
	          if(isTL){
	          for(int index =0 ;index <no_of_TL; index++){
	            if(!_TL_Queue[index].empty()){     //TL queue is not empty; so this is the 1st message in the queue.
				f = _TL_Queue[index].front();
				if((f->tltime == cycle) && (f->from_router == this->GetID())){// && (f->from_input_port == input)){
				     _TL_Queue[index].pop( );
				     
				     
				      if(f->pid == 0){
		       			//cout<<"Initial TL_BUF for 0 = "<<f->tl_buf_counter<<endl;
		 		      }
			          
			          	f->tl_buf_counter = f->tl_buf_counter + (GetSimTime() - f->temp);
				 	if(f->pid == 0){
		       				//cout<<"TL_BUF for 0 = "<<f->tl_buf_counter <<" and cycle time = "<<cycle<<endl;
		 			}
				     //Dipika: For TL buffer: subtract the saved cycle from the present cycle(_time);
				      
				     
				     ofile<<"##################NOWHEREEEE At Router:"<<f->from_router<<"  Check{"<<f->from_router<<"}. for pkt("
	       					<<f->pid<<") at time= "<< cycle<<"........................."<<endl<<endl;
				     ofile<<"size of TL_queue["<<index<<"]: "<<_TL_Queue[index].size()<<endl<<endl;	
				     ret = _Check_Received_Flits(f);
				} 		
			 }   
	         } // end of for loop */
	       } // if statement 
	 
	  
	  
		f = (*_input_channels)[input]->Receive(); // get a flit in f
		
		if(f){
		 //Dipika: For input buffer: subtract the saved cycle from the present cycle(_time);
		 if(f->pid == 0){
		     // cout<<endl<<endl<<"Initially Router_IP_Buf for 0 = "<<f->rc_ip_buf_counter <<" and cycle time = "<<cycle<<"  &f->temp = "<<f->temp<<endl;
		 }
		 f->rc_ip_buf_counter = f->rc_ip_buf_counter + (GetSimTime() - f->temp);
		 
		 if(f->pid == 0){
		     // cout<<"Router_IP_Buf counter for 0 = "<<f->rc_ip_buf_counter <<" and cycle time = "<<cycle<<endl;
		 }
		 f->temp = 0;
		/*********************************************************************************/
		 
		 f->from_router  = this->GetID();
		 f->from_input_port = input;
		 f->temp1 = cycle;
                 if(f->pid == 0){
		    //cout<<"Router_COunter STart for 0 = "<<f->temp1<<" and cycle time  = "<<GetSimTime()<<endl;
                 }
		 ret = _Check_Received_Flits(f);
		 
		 if(ret == 0){
		  //cout<<"Go to next router. Present Router:"<<this->GetID()<<" for pkt("<<f->pid<<"). from router"<<f->from_router<<endl;
		  continue;
		 // cout<<"This SHouldn't get printed......"<<endl;
		 } 
	 
	      
		 if(input == 5){
		       ofile<<"##### Flit("<<f->pid<<") received at input port 5 at Router:"<<this->GetID()<<" & cycle = "<<cycle<<endl;
 	              //Dipika: For number of TL links traversed, add a counter here and increment it.
         	      (f->tl_link_counter )++;
         	     // Token_Req[f->tlsrc][f->tldest] = -1;
         	    //  WakeUP_Recv_Sender[f->tlsrc][f->tldest] = -1;
         	    
		 }else{
		     //Dipika: For number of links traversed, add a counter here and increment it.
		   //  if(input != 4)
		    // (f->rc_link_counter)++;
		 
		 } 
	      }
		
	} // end for
	ofile.close();
} // end _ReceiveFlits( )



/*************************************************dipika*************************************************************************/
int IQRouterBase:: _Check_Received_Flits(Flit *f){
    bufferMonitor.cycle() ;
    int input;
    int ret;
        
     if ( f ){
  	    ofstream ofile;
            ofile.open("track.txt",ios::app);
            ofile<<"AT Router: "<<this->GetID()<<" pkt("<<f->pid<<") , SRC:"<<f->src<<" Dest:"<<f->dest<<" & cycle = "<<cycle<<endl;
            ofile.close();
           
            if(isTL){ 
                 Cal_Dist_Src_Dest(f);
              // if((f->take_tl == true) && (GetSimTime() % 4 == 0)){
               if(f->take_tl == true){
                  ret = _Check_TL_Required(f);     //cout<<"Dipika: Returned from token: "<<ret<<endl;   //0->queue the pkt, 1->Bus accepted, -999 -> perform as usual
                  if(ret == 0){
                   return (0);
                  }
               }
            }
		   
		    input = f->from_input_port;
                    ++_received_flits[input];  /// increment flit count
		      	VC * cur_vc = _vc[input][f->vc];

		      	if ( cur_vc->GetState( ) == VC::idle )
			{
				if ( !f->head )
				{
			    		Error( "Received non-head flit at idle VC" );
			  	}
			  	cur_vc->SetState( VC::routing );
                            // cout<<"in IQ router/base.cpp, inserting into _routing_vcs = "<<(input*_vcs+ f->vc)<<endl;
			  	_routing_vcs.push(input*_vcs+f->vc);
		      	}

		      	if(f->watch)
			{
			*gWatchOut << GetSimTime() << " | " << FullName() << " | "
				   << "Adding flit " << f->id
				   << " to VC " << f->vc
				   << " at input " << input
				   << " (state: " << VC::VCSTATE[cur_vc->GetState()];
				if(cur_vc->Empty())
				{
			  		*gWatchOut << ", empty";
				}
				else
				{
		  			assert(cur_vc->FrontFlit());
		  			*gWatchOut << ", front: " << cur_vc->FrontFlit()->id;
				}
				*gWatchOut << ")." << endl;
				*gWatchOut << GetSimTime() << " | " << FullName() << " | "
					   << "Received flit " << f->id
					   << " from channel at input " << input
					   << "." << endl;
	      		}
			if ( !cur_vc->AddFlit( f ) )
			{
				Error( "VC buffer overflow" );
			}
			bufferMonitor.write( input, f ) ;
		} // end if (f)
  
}





int IQRouterBase:: _Check_TL_Required(Flit *f){
      int cases = -999;     //cases = 0->if src = TL_SRC; 1-> if src = TL_dest; else = -999
      int turn = -999;    //  0/1/2/3/4 -> if Left/Right/Up/Down Node of destination is a TL_dest
      int index = -999;
      int ret;
      
      for(index = 0; index < no_of_TL; index++){
               if(this->GetID() == TL_SRC_DEST[index].src){       
			cases = 0;
			
		  	if((f->dest == TL_SRC_DEST[index].dest) || (TL_SRC_DEST[index].dest == _LeftNode(f->dest, 0)) || (TL_SRC_DEST[index].dest == _LeftNode(f->dest, 1))
		  	 || (TL_SRC_DEST[index].dest == _RightNode(f->dest, 0)) || (TL_SRC_DEST[index].dest == _RightNode(f->dest, 1))
		  	 || (TL_SRC_DEST[index].dest == _LeftNode(_LeftNode(f->dest, 0), 1))|| (TL_SRC_DEST[index].dest == _RightNode(_LeftNode(f->dest, 0), 1)) 
		  	 || (TL_SRC_DEST[index].dest == _RightNode(_RightNode(f->dest, 0), 1)) || (TL_SRC_DEST[index].dest == _LeftNode(_RightNode(f->dest, 0), 1))  ) {
		  	  f->tltime = cycle;
		  	  f->Bus = index;
		  	  turn = 0;
		  	  f->tl = true;
			  f->tlsrc = TL_SRC_DEST[index].src;
		  	  f->tldest = TL_SRC_DEST[index].dest;
		  	  ret = TL_TokenReq( index, f );
		  	  return(ret);
		  	  break;
		  	  
		  	}else{
		  	      cases = -999;
		  	      turn = -999;
		       }
		  		
		  		
       }else if(this->GetID() == TL_SRC_DEST[index].dest){
		  cases = 1;
		  
		  if((f->dest == TL_SRC_DEST[index].src) || (TL_SRC_DEST[index].src == _LeftNode(f->dest, 0)) || (TL_SRC_DEST[index].src == _LeftNode(f->dest, 1))
		  || (TL_SRC_DEST[index].src == _RightNode(f->dest, 0)) || (TL_SRC_DEST[index].src == _RightNode(f->dest, 1)) 
		  || (TL_SRC_DEST[index].src == _LeftNode(_LeftNode(f->dest, 0), 1))|| (TL_SRC_DEST[index].src == _RightNode(_LeftNode(f->dest, 0), 1)) 
		  || (TL_SRC_DEST[index].src == _RightNode(_RightNode(f->dest, 0), 1)) || (TL_SRC_DEST[index].src == _LeftNode(_RightNode(f->dest, 0), 1)) ){
		  	f->tltime = cycle;
		  	  f->Bus = index;
		    	turn = 0;
		    	f->tl = true;
		        f->tlsrc = TL_SRC_DEST[index].dest;
		        f->tldest = TL_SRC_DEST[index].src;
		        ret = TL_TokenReq( index, f );			
		        break; 
		        
		  }else{
		  	      cases = -999;
		  	      turn = -999;
		  	
		  }
		
		
		}else{
		  cases = -999;
		  turn = -999;
		}
		
	     if(((cases == 0) || (cases == 1))  && turn != -999){
	        return(ret);
	        
	     } 
	
	  }	// end of 1st for loop


 if((cases == -999) && ( turn == -999)){	  
	  
     for(index = 0; index < no_of_TL; index++){  
		  
	if(( this->GetID() == _LeftNode(TL_SRC_DEST[index].src, 0)) || ( this->GetID() == _LeftNode(TL_SRC_DEST[index].src, 1)) || (this->GetID() == _RightNode(TL_SRC_DEST[index].src, 0)) 
	|| ( this->GetID()  == _RightNode(TL_SRC_DEST[index].src, 1)) || (this->GetID() == _LeftNode(_LeftNode(TL_SRC_DEST[index].src, 0), 1))
	|| (this->GetID() == _RightNode(_LeftNode(TL_SRC_DEST[index].src, 0), 1)) || (this->GetID() == _RightNode(_RightNode(TL_SRC_DEST[index].src, 0), 1)) 
	|| (this->GetID() == _LeftNode(_RightNode(TL_SRC_DEST[index].src, 0), 1))   ){
	        cases = 2;
	                 f->tl = false;
		          
	        	if((f->dest == TL_SRC_DEST[index].dest) || (f->dest == _LeftNode(TL_SRC_DEST[index].dest, 0)) || (f->dest == _LeftNode(TL_SRC_DEST[index].dest, 1)) 
	        	|| (f->dest == _RightNode(TL_SRC_DEST[index].dest, 0)) || (f->dest == _RightNode(TL_SRC_DEST[index].dest, 1)) 
	        	|| (f->dest == _LeftNode(_LeftNode(TL_SRC_DEST[index].dest, 0), 1))|| (f->dest == _RightNode(_LeftNode(TL_SRC_DEST[index].dest, 0), 1)) 
		        || (f->dest == _RightNode(_RightNode(TL_SRC_DEST[index].dest, 0), 1)) || (f->dest == _LeftNode(_RightNode(TL_SRC_DEST[index].dest, 0), 1))
	        	){
		  	    f->tltime = cycle;
		  	    f->Bus = index;
	        	    f->tlsrc = this->GetID();
	                    f->tldest = TL_SRC_DEST[index].src;
	                    turn = 0;
	                    break;
	                    
		  	}else{
		  	      cases = -999;
		  	      turn = -999;
         	  	 }  
		  	 
		  	      
        }else if(( this->GetID() == _LeftNode(TL_SRC_DEST[index].dest, 0)) || ( this->GetID() == _LeftNode(TL_SRC_DEST[index].dest, 1)) || ( this->GetID() == _RightNode(TL_SRC_DEST[index].dest, 0)) || ( this->GetID() == _RightNode(TL_SRC_DEST[index].dest, 1)) || (this->GetID() == _LeftNode(_LeftNode(TL_SRC_DEST[index].dest, 0), 1))
        || (this->GetID() == _RightNode(_LeftNode(TL_SRC_DEST[index].dest, 0), 1)) || (this->GetID() == _RightNode(_RightNode(TL_SRC_DEST[index].dest, 0), 1)) 
        || (this->GetID() == _LeftNode(_RightNode(TL_SRC_DEST[index].dest, 0), 1))
	        	      
        ){
	        cases = 3;
	        
	        f->tl = false;
	        
	        	if((f->dest == TL_SRC_DEST[index].src) || (f->dest == _LeftNode(TL_SRC_DEST[index].src, 0)) || (f->dest == _LeftNode(TL_SRC_DEST[index].src, 1)) 
	        	|| (f->dest == _RightNode(TL_SRC_DEST[index].src, 0)) || (f->dest == _RightNode(TL_SRC_DEST[index].src, 1)) 
	        	|| (f->dest == _LeftNode(_LeftNode(TL_SRC_DEST[index].src, 0), 1))|| (f->dest == _RightNode(_LeftNode(TL_SRC_DEST[index].src, 0), 1)) 
		        || (f->dest == _RightNode(_RightNode(TL_SRC_DEST[index].src, 0), 1)) || (f->dest == _LeftNode(_RightNode(TL_SRC_DEST[index].src, 0), 1))
	        	
	        	){
		  	   f->tltime = cycle;
		  	  f->Bus = index;
	        	   f->tlsrc = this->GetID();
	                   f->tldest = TL_SRC_DEST[index].dest;
	                    turn = 0;
          		    break;
	         	    
		  	}else{
		  	      cases = -999;
		  	      turn = -999;
		  	}        
         }else{
           cases = -999;
           turn = -999;
         }


            ofstream ofile;
            ofile.open("track.txt",ios::app);	    
	
	if(cases != -999 && turn != -999){
	    ofile<<" Pkt("<<f->pid<<") , At Router:"<<this->GetID()<<" will require Bus:"<<(index+1)<<" for SRC:"<<f->src<<" ,DEST:"<<f->dest<<" ,for TLSRC:"<<f->tlsrc<<" TLDEST:"<<f->tldest<<" cases="<<cases<<" & turn = "<<turn<<endl;
	 ofile.close();   
	   return(-999);
	}else{
	    return(-999);	
	}    
	
       }	
      }// end for 2nd loop
          
}



int IQRouterBase:: next_port( int cur, int dest )//current router, destination router
{
  int dim_left;
  int out_port;
//  int gN = 2;
 // int gK = 8;
  //n dim k nodes
  for ( dim_left = 0; dim_left < gN; ++dim_left ) {

    if ( ( cur % gK ) != ( dest % gK ) ) { break; }
    cur /= gK; dest /= gK;
  }

  if ( dim_left < gN ) //dimensions left to traverse
  {
    cur %= gK; dest %= gK;

    if ( cur < dest ) //in a particular dimension either right or left port can be choosen
    {
      out_port =  2*dim_left;     // Right
    }
    else
    {
      out_port = 2*dim_left + 1; // Left
    }
  }
  else //no more dimensions left i.e., reached dest
  {
    out_port = 2*gN;  // Eject
  }
  return out_port;
}


int IQRouterBase:: _Cal_TL_(Flit *f){
      int cases = -999;     //cases = 0->if src = TL_SRC; 1-> if src = TL_dest; else = -999
      int turn = -999;    //  0/1/2/3/4 -> if Left/Right/Up/Down Node of destination is a TL_dest
      int index = -999;
      int ret;
      int counter = 0;
     
      for(index = 0; index < no_of_TL; index++){
               if(f->src  == TL_SRC_DEST[index].src){       
			cases = 0;
			if((f->dest == TL_SRC_DEST[index].dest) || (TL_SRC_DEST[index].dest == _LeftNode(f->dest, 0)) || (TL_SRC_DEST[index].dest == _LeftNode(f->dest, 1))
		  	|| (TL_SRC_DEST[index].dest == _RightNode(f->dest, 0)) || (TL_SRC_DEST[index].dest == _RightNode(f->dest, 1)) ){
		  	  f->tltime = cycle;
		  	  f->Bus = index;
		  	  turn = 0;
		  	  f->tl = true;
			  f->tlsrc = TL_SRC_DEST[index].src;
		  	  f->tldest = TL_SRC_DEST[index].dest;
		  	  return(0);
		  	  break;
		  	  
		  	  
		  	}else{
		  	      cases = -999;
		  	      turn = -999;
		       }
		  		
		  		
       }else if(f->src  == TL_SRC_DEST[index].dest){
		  cases = 1;
		 
		  if((f->dest == TL_SRC_DEST[index].src) || (TL_SRC_DEST[index].src == _LeftNode(f->dest, 0)) || (TL_SRC_DEST[index].src == _LeftNode(f->dest, 1))
		  || (TL_SRC_DEST[index].src == _RightNode(f->dest, 0)) || (TL_SRC_DEST[index].src == _RightNode(f->dest, 1))){
		        f->tltime = cycle;
		  	f->Bus = index;
		    	turn = 0;
		    	f->tl = true;
		        f->tlsrc = TL_SRC_DEST[index].dest;
		        f->tldest = TL_SRC_DEST[index].src;
		  	return(0);
  		        break; 
		        
		        
		  }else{
		  	      cases = -999;
		  	      turn = -999;
		  	
		  }
		
		
		}else{
		  cases = -999;
		  turn = -999;
		}
		
	     if(((cases == 0) || (cases == 1))  && turn != -999){
	        return(ret);
	        
	     } 
	
	  }	// end of 1st for loop


 if((cases == -999) && ( turn == -999)){	  
	  
     for(index = 0; index < no_of_TL; index++){  
		  
	if(( f->src  == _LeftNode(TL_SRC_DEST[index].src, 0)) || ( f->src  == _LeftNode(TL_SRC_DEST[index].src, 1)) || (f->src  == _RightNode(TL_SRC_DEST[index].src, 0)) || ( f->src   == _RightNode(TL_SRC_DEST[index].src, 1)) ){
	        cases = 2;
	                 f->tl = false;
		  
	        	if((f->dest == TL_SRC_DEST[index].dest) || (f->dest == _LeftNode(TL_SRC_DEST[index].dest, 0)) || (f->dest == _LeftNode(TL_SRC_DEST[index].dest, 1)) 
	        	|| (f->dest == _RightNode(TL_SRC_DEST[index].dest, 0)) || (f->dest == _RightNode(TL_SRC_DEST[index].dest, 1))){
		  	    f->tltime = cycle;
		  	    f->Bus = index;
		  	    f->tlsrc = f->src;
	                    f->tldest = TL_SRC_DEST[index].src;
	                    turn = 0;
			    break;
	                    
		  	}else{
		  	      cases = -999;
		  	      turn = -999;
         	  	 }  
		  	 
		  	      
        }else if(( f->src  == _LeftNode(TL_SRC_DEST[index].dest, 0)) || (f->src  == _LeftNode(TL_SRC_DEST[index].dest, 1)) || ( f->src  == _RightNode(TL_SRC_DEST[index].dest, 0)) || ( f->src  == _RightNode(TL_SRC_DEST[index].dest, 1)) ){
	        cases = 3;
	        
	     
	        f->tl = false;
	        
	        	if((f->dest == TL_SRC_DEST[index].src) || (f->dest == _LeftNode(TL_SRC_DEST[index].src, 0)) || (f->dest == _LeftNode(TL_SRC_DEST[index].src, 1)) 
	        	|| (f->dest == _RightNode(TL_SRC_DEST[index].src, 0)) || (f->dest == _RightNode(TL_SRC_DEST[index].src, 1)) ){
		  	  f->tltime = cycle;
		  	   f->Bus = index;
	        	   f->tlsrc = f->src;
	                   f->tldest = TL_SRC_DEST[index].dest;
	                   turn = 0;
	                     if(f->pid == 73){
	          cout<<"HERE::::::::::::::::::::"<<endl;
	        }
	       		   break;	         	    
		  	}else{
		  	      cases = -999;
		  	      turn = -999;
		  	}        
         }else{
           cases = -999;
           turn = -999;
         }	
      }// end for 2nd loop
      
   } 
          
}

int IQRouterBase:: Cal_Dist_Src_Dest(Flit *f){
    
    if(f->attempts > 0){
    f->attempts--;
    Flit *fp = new Flit( );
    fp->pid = f->pid;
    fp->src = f->src;
    fp->dest = f->dest;
    int tl_dist = 0; //With TL;
    int ret;
    int tl_counter = 0;
    int cur = this->GetID();
    int counter = 0;
    fp->src = cur;
    int tl_cycles, rc_cycles;
    
 here: ret = _Cal_TL_(fp);  
    if(fp->tlsrc != -999 && fp->tldest != -999){
        if(fp->tl){
           tl_counter++;
           ret = 5;
        }else{
          ret = next_port(cur, fp->tldest);
          if(ret == 0 ){
       		cur = _RightNode(cur , 0);
         }else if(ret == 1){
       		cur = _LeftNode(cur , 0);
         }else if(ret == 2){
       		cur = _RightNode(cur , 1);
         }else{
      	     if(ret == 3 ){
          	cur = _LeftNode(cur , 1);
            }
         }
          counter++;
       }
        
        cur = fp->tldest;
        fp->src = cur;
        fp->tlsrc = fp->tldest = -999;
        fp->tltime = -999;
	fp->Bus = -999;
	fp->tl = false;
	
    }else{
        ret = next_port(cur, fp->dest);
       if(ret == 0 ){
       		cur = _RightNode(cur , 0);
       	  }else if(ret == 1){
       		cur = _LeftNode(cur , 0);
       	  }else if(ret == 2){
       		cur = _RightNode(cur , 1);
       	  }else{
      	     if(ret == 3 ){
          	cur = _LeftNode(cur , 1);
            }
         }
       fp->src = cur;
       counter++;
    }
   
 
    if(ret != 4){
     goto here;
    }
    
  //cout<<endl<<"Number of tllinks = "<<tl_counter<<"  and #RC links = "<<counter-1<<endl;
   tl_cycles = (tl_counter + (counter - 1)) * 2 + (counter -1 )+ tl_counter*2;
   //cout<<endl<<" TL cycles = "<<tl_cycles<<"\t";
    
    int normal_dist = 0; //Without TL;
    counter = 0;
    cur = this->GetID();
    //cout<<endl<<"Without TL Router:"<<endl<<endl;
//Normal Path
 while((ret = next_port(cur , f->dest)) != 4){
   if(ret == 0 ){
       cur = _RightNode(cur , 0);
   }else if(ret == 1){
       cur = _LeftNode(cur , 0);
   }else if(ret == 2){
       cur = _RightNode(cur , 1);
   }else{
      if(ret ==3 ){
       cur = _LeftNode(cur , 1);
      }
   }
   counter++;
 }

   rc_cycles =(counter*2 + counter);
   //cout<<"RC cycles = "<<rc_cycles<<endl;
   
   if(tl_cycles < rc_cycles){
     f->take_tl = true;
   }else{
     f->take_tl = false;
   }
 }
   
   
    
}


 int IQRouterBase::Check_One_Hop_Dist(Flit *f){
       if((( _LeftNode(f->tlsrc, 0) == f->src ) && ( _LeftNode(f->tlsrc, 1) == f->dest  ))  || (( _LeftNode(f->tlsrc, 0) == f->src) && ( _RightNode(f->tlsrc, 0) == f->dest)) || ((  _LeftNode(f->tlsrc, 1) == f->src ) && ( _RightNode(f->tlsrc, 0) == f->dest)) || (( _LeftNode(f->tlsrc, 0) == f->src) && ( _RightNode(f->tlsrc, 1) == f->dest)) || (( _RightNode(f->tlsrc, 0) == f->src) && ( _RightNode(f->tlsrc, 1) == f->dest))){
         f->tlsrc = -1;
         f->tldest = -1;
         f->Bus = -999;
         f->tl = false;
         f->tltime = -999;
         Token_Req[f->tlsrc][f->tldest] = -1;
         WakeUP_Recv_Sender[f->tlsrc][f->tldest] = -1;
           return (-999);
       }else{
           return(1);
       }
      
 }



int IQRouterBase::TL_TokenReq( int index, Flit *f ){
          ofstream ofile;
          ofile.open("track.txt",ios::app);
          
          if((bus_status[index].pid == -999) || (bus_status[index].time == -999)){
                Token_Req[f->tlsrc][f->tldest] = -1;
         	WakeUP_Recv_Sender[f->tlsrc][f->tldest] = -1;
          }
          
         if(!token[index] && (bus_status[index].time == -999) && (Token_Req[f->tlsrc][f->tldest] != 1) && (WakeUP_Recv_Sender[f->tlsrc][f->tldest] != 1)){   //Bus is free
                int ret = Check_One_Hop_Dist(f);
                if(ret == -999){
                	return(2);
         	}
         	Token_Req[f->tlsrc][f->tldest] = 1;
         	WakeUP_Recv_Sender[f->tlsrc][f->tldest] = 1;
         	token[index] = true;
         	bus_status[index].pid = f->pid;
         	bus_status[index].time = f->tltime;
         	ofile<<endl<<" Bus Number: "<<(index + 1)<<" is accepted to pkt("<<f->pid<<") , SRC:"<<f->src<<" DEST:"<<f->dest<<"{Check: pid:"<<bus_status[index].pid<<"}"<<endl;
         	ofile<<"  token["<<index<<"]= "<<token[index]<<" Last_TL_USED["<<index<<"]="<<bus_status[index].time<<"  at time = "<<cycle<<endl;
         	ofile<<" TLSRC:"<<f->tlsrc<<" TLDEST: "<<f->tldest<<" Flag1, Token_Req=" <<Token_Req[f->tlsrc][f->tldest]<<" Flag2, Wake = "<<  WakeUP_Recv_Sender[f->tlsrc][f->tldest]<<endl<<endl<<endl;
         	return(1);        
      }else{
               if(bus_status[index].time == cycle){
           		ofile<<endl<<"Bus:"<<(index+1)<<" is Busy at cycle:"<<cycle<<" [Requesting pkt("<<f->pid<<")].. [Currently Using Pkt:"<<bus_status[index].pid<<"] at Router:"<<this->GetID()<<endl;
            		ofile<<"  token["<<index<<"]= "<<token[index]<<" Last_TL_USED["<<index<<"]="<<bus_status[index].time<<endl;
            		ofile<<" TLSRC:"<<f->tlsrc<<" TLDEST: "<<f->tldest<<" Flag1, Token_Req=" <<Token_Req[f->tlsrc][f->tldest]<<" Flag2, Wake = "<<  WakeUP_Recv_Sender[f->tlsrc][f->tldest]<<endl<<endl<<endl;
            		//cout<<endl<<"Bus:"<<(index+1)<<" is Busy [Requesting pkt("<<f->pid<<")].. [Currently Using Pkt:"<<bus_status[index].pid<<"] at Router:"<<this->GetID()<<endl;
            		//cout<<"  token["<<index<<"]= "<<token[index]<<" Last_TL_USED["<<index<<"]="<<bus_status[index].time<<endl;
         	}else if(f->tl == false){
           		ofile<<"Wrong Request Generated........."<<endl;
         	}else{
            		ofile<<endl<<"Bus:"<<(index+1)<<" is Busy at cycle:"<<cycle<<" [Requesting pkt("<<f->pid<<")].. [Currently Using Pkt:"<<bus_status[index].pid<<"]"<<endl;
            		ofile<<"  token["<<index<<"]= "<<token[index]<<" Last_TL_USED["<<index<<"]="<<bus_status[index].time<<endl;
            		ofile<<" TLSRC:"<<f->tlsrc<<" TLDEST: "<<f->tldest<<" Flag1, Token_Req=" <<Token_Req[f->tlsrc][f->tldest]<<" Flag2, Wake = "<<  WakeUP_Recv_Sender[f->tlsrc][f->tldest]<<endl<<endl<<endl;
         	}
         	f->tlsrc = -1;
         	f->tldest = -1;
         	f->Bus = -999;
         	f->tl = false;
         	f->tltime = -999;
         	
         	//f->attempts--;
         	Token_Req[f->tlsrc][f->tldest] = -1;
         	WakeUP_Recv_Sender[f->tlsrc][f->tldest] = -1;
         //	token[index] = false;
         	TL_enqueue(f,index);
          	return(0);   //0 is an error code
         
      }
  
  
     ofile.close();
   }


 int IQRouterBase::AdvanceTime( Flit *f ){
     f->tltime++;
     bus_status[f->Bus].time = bus_status[f->Bus].time + 1;
 }

int IQRouterBase::TL_enqueue(Flit *f, int index){

         ofstream ofile;
         ofile.open("track.txt",ios::app);
          
	if(_TL_Queue[index].size() == 0){     //TL queue is empty; so this is the 1st message in the queue.
		f->tltime = cycle + 1;
		_TL_Queue[index].push(f);
		
		//Dipika: For TL buffer: save the present cycle(_time);
		 f->temp = cycle;
		 
		// cout<<" Size of TL_Queue["<<index+1<<"] : "<<_TL_Queue[index].size()<<" at time = "<<cycle<<endl;
		 
		ofile<<"Check:: First message to enqueue at: "<<cycle<<": & dequeued:"<<f->tltime<<" TL Queue: pid("<<f->pid<<") for Bus Number: "<<index+1<<endl; 
		//cout<<"Check:: First message to enqueue at: "<<cycle<<": & dequeued:"<<f->tltime<<" :TL Queue: pid("<<f->pid<<") for Bus Number: "<<index+1<<endl; 
	}else{
		Flit *fp;
		fp = _TL_Queue[index].back();
		f->tltime = 1 + fp->tltime;  //use the bus for 2 cycle. 	
	        _TL_Queue[index].push(f);
	        
	         f->temp = cycle;
	         
		// cout<<" Size of TL_Queue["<<index+1<<"] : "<<_TL_Queue[index].size()<<" at time = "<<cycle<<endl;
		
	        ofile<<"\n TL Message Queued at:"<<cycle<<": & dequeued:"<<f->tltime<<" for Pid("<<f->pid<<") for Bus Number:"<<index+1<<"\n"<<endl;
	       // cout<<"\n TL Message Queued at:"<<cycle<<": & dequeued:"<<f->tltime<<" for Pid("<<f->pid<<") for Bus Number:"<<index+1<<"\n"<<endl;
	       // cout<<"......done.......size = "<<_TL_Queue[index].size()<<endl<<endl;
	       // cout<<"Bus is busy at cycle = "<<cycle <<" .Incoming Flit is scheduled at "<<f->tltime<<" time."<<endl;   	  		  
	}
	
	ofile.close();
}

int IQRouterBase::_LeftNode( int node, int dim ) // computation of left node of a node
{
	int k_to_dim = pow( gK, dim );
	int loc_in_dim = ( node / k_to_dim ) % gK;
 	int left_node;
	// if at the left edge of the dimension, wraparound
	if ( loc_in_dim == 0 )
	{
		left_node = node + (gK-1)*k_to_dim;
	}
	else
	{
	    left_node = node - k_to_dim;
	}

	return left_node;
}

int IQRouterBase::_RightNode( int node, int dim )  // computation of right node of a node
{
	int k_to_dim = pow( gK, dim );
	int loc_in_dim = ( node / k_to_dim ) % gK;
	int right_node;
	// if at the right edge of the dimension, wraparound
	if ( loc_in_dim == ( gK-1 ) )
	{
		right_node = node - (gK-1)*k_to_dim;
	}
	else
	{
		right_node = node + k_to_dim;
	}

	return right_node;
}

/*************************************************dipika*************************************************************************/



void IQRouterBase::_ReceiveCredits( )
{
  	Credit *c;
	// from each output port , if credit is available do...
  	for ( int output = 0; output < _outputs; ++output )
	{  
    		c = (*_output_credits)[output]->Receive();
    		if ( c )
		{
			//cout<<"Processing credits , cycle:"<< cycle << " for Router:"<<this->GetID()<<" at port:"<<output<<endl;
      			_next_vcs[output]->ProcessCredit( c );      			
      			delete c;
    		}
  	}
}

void IQRouterBase::_InputQueuing( )
{
  /*
  for ( int input = 0; input < _inputs; ++input ) {
    for ( int vc = 0; vc < _vcs; ++vc ) {

      VC * cur_vc = &_vc[input][vc];
      
      if ( cur_vc->GetState( ) == VC::idle ) {
	Flit * f = cur_vc->FrontFlit( );

	if ( f ) {
	  if ( !f->head ) {
	    Error( "Received non-head flit at idle VC" );
	  }

	  cur_vc->SetState( VC::routing );
	}
      }
    }
  } 
  */ 
}

//this function relies on the fact that _routing delay is constant for all packets
//if the packet at the head of the queue is <routing_delay, then all other vc in the queue
//will be <routing delay
void IQRouterBase::_Route( )
{
	int size = _routing_vcs.size();
	for(int i = 0; i<size; i++)
	{
	    	int vc_encode = _routing_vcs.front();
	    	VC * cur_vc = _vc[vc_encode/_vcs][vc_encode%_vcs];
	    	if(cur_vc->GetStateTime( ) >= _routing_delay)
		{
	      		Flit * f = cur_vc->FrontFlit( );
	      		cur_vc->Route( _rf, this, f,  vc_encode/_vcs);
	      		cur_vc->SetState( VC::vc_alloc ) ;
                        // cout<<"In RouteFunc.cpp, pkt("<<f->pid<<") has been alloacte VC"<<endl;
	      		_vcalloc_vcs.insert(vc_encode);  //dipika: this keeps track of the pkts for which VC has been allocated and then pop those packets from routing_vc's
	      		_routing_vcs.pop();
	    	}
		else
		{
	      		break;
	    	}
	}  // end for size

} // end _Route ()


void IQRouterBase::_OutputQueuing( )
{

	for ( int output = 0; output < _outputs; ++output ) 
	{
		for ( int t = 0; t < _output_speedup; ++t ) 
		{
			int expanded_output = _outputs*t + output;
		      	Flit * f = _crossbar_pipe->Read( expanded_output );

		      	if ( f )
			{
				_output_buffer[output].push( f );
				if(f->watch)
			  		*gWatchOut << GetSimTime() << " | " << FullName() << " | "
				      << "Buffering flit " << f->id
				      << " at output " << output
				      << "." << endl;
	      		}
	    	}
	}  // end for output

	for ( int input = 0; input < _inputs; ++input ) 
	{
		Credit * c = _credit_pipe->Read( input );

	    	if ( c )
		{
	      		_in_cred_buffer[input].push( c );
	    	}
	} // end for input
} // end OutputQueuing

void IQRouterBase::_SendFlits( )
{
	Flit *f;
        ofstream ofile;
        ofile.open("track.txt",ios::app);
            
	for ( int output = 0; output < _outputs; ++output )
	{
		// if output buffer is not empty (for each output port)
		if ( !_output_buffer[output].empty( ) )
		{
	      		f = _output_buffer[output].front( );
	      		
				 if(f->pid == 0){
		       			//cout<<"Initial Router_COunter for 0 = "<<f->router_counter<<" at time = "<<cycle<<endl;
		 		}
		 	/*	 if(f->router_counter == 0){
		 		  f->router_counter +=1;
		 		 }
		 	*/	 
			         f->router_counter = f->router_counter + (GetSimTime() - f->temp1);
			         if(f->pid == 0){
		       			//cout<<"Router_COunter for 0  = "<<f->router_counter<<" and cycle time = "<<cycle<<endl;
		 		}
      				 f->temp1 = 0;
      				 
	      		f->from_router = this->GetID();
	      		_output_buffer[output].pop( );
	      		++_sent_flits[output];
	      		f->temp = cycle + 1;
	      	
	      	/*****************Dipika********************************/	
	      	//if(output == 5){
	      	if(f->tlsrc != -1 && f->tldest != -1){
		 ofile<<"###############Flit("<<f->pid<<") sending from Router: "<<this->GetID()<<"  & cycle = "<<cycle<<endl;
		 f->tltime = -999;
		 f->tl = false;
		 bus_status[f->Bus].pid = -999;
		 bus_status[f->Bus].time = -999;
		 Token_Req[f->src][f->dest] = -1;
		 WakeUP_Recv_Sender[f->src][f->dest] = -1;
		 token[f->Bus] = false;
		 f->tlsrc = -1;
		 f->tldest = -1;
		 f->Bus = -999;
		}
	      		
	      	/**********************************************************************************************/
	      		
	      		if(f->watch)
				*gWatchOut << GetSimTime() << " | " << FullName() << " | "
			    << "Sending flit " << f->id
			    << " to channel at output " << output
			    << "." << endl;
	    	}
		else
		{
	      		f = 0;
	    	}
	    	if(gTrace && f)
		{
			cout<<"Outport "<<output<<endl;cout<<"Stop Mark"<<endl;
		}
		
		
	    	(*_output_channels)[output]->Send( f );
	    	
	} // end for

   ofile.close();
} // end _SendFlits*()

void IQRouterBase::_SendCredits( )
{
	Credit *c;
	// send credit through every input channel
	for ( int input = 0; input < _inputs; ++input )
	{
		if ( !_in_cred_buffer[input].empty( ) )
		{
	      		c = _in_cred_buffer[input].front( );
	      		_in_cred_buffer[input].pop( );
	    	}
		else
		{
	      		c = 0;
	    	}
		(*_input_credits)[input]->Send( c );
	} // end for
}



void IQRouterBase::Display( ) const
{
  	for ( int input = 0; input < _inputs; ++input )
	{
    		for ( int v = 0; v < _vcs; ++v )
		{
      			_vc[input][v]->Display( );
    		}
  	}
}

int IQRouterBase::GetCredit(int out, int vc_begin, int vc_end ) const
{
 

  const BufferState *dest_vc;
  int    tmpsum = 0;
  int cnt = 0;
  
  if (out >= _outputs ) {
    cout << " ERROR  - big output  GetCredit : " << out << endl;
    exit(-1);
  }
  
  dest_vc = _next_vcs[out];
  //dest_vc_tmp = &_next_vcs_tmp[out];
  
  if (vc_begin == -1) {
    for (int v =0;v<_vcs;v++){
      tmpsum+= dest_vc->Size(v);
    }
    return tmpsum;
  }  else if (vc_begin != -1) {
    assert(vc_begin >= 0);
    for (int v =vc_begin;v<= vc_end ;v++)  {
      tmpsum+= dest_vc->Size(v);
      cnt++;
    }
    return tmpsum;
  }
  assert(0); // Should never reach here.
  return -5;
}

int IQRouterBase::GetBuffer(int i) const {
  int size = 0;
  int i_start = (i >= 0) ? i : 0;
  int i_end = (i >= 0) ? i : (_inputs - 1);
  for(int input = i_start; input <= i_end; ++input) {
    for(int vc = 0; vc < _vcs; ++vc) {
      size += _vc[input][vc]->GetSize();
    }
  }
  return size;
}

int IQRouterBase::GetReceivedFlits(int i) const {
  int count = 0;
  int i_start = (i >= 0) ? i : 0;
  int i_end = (i >= 0) ? i : (_inputs - 1);
  for(int input = i_start; input <= i_end; ++input)
    count += _received_flits[input];
  return count;
}

int IQRouterBase::GetSentFlits(int o) const {
  int count = 0;
  int o_start = (o >= 0) ? o : 0;
  int o_end = (o >= 0) ? o : (_outputs - 1);
  for(int output = o_start; output <= o_end; ++output)
    count += _sent_flits[output];
  return count;
}

void IQRouterBase::ResetFlitStats() {
  for(int i = 0; i < _inputs; ++i)
    _received_flits[i] = 0;
  for(int o = 0; o < _outputs; ++o)
    _sent_flits[o] = 0;
}


// ----------------------------------------------------------------------
//
//   Switch Monitor
//
// ----------------------------------------------------------------------
SwitchMonitor::SwitchMonitor( int inputs, int outputs ) {
  // something is stomping on the arrays, so padding is applied
  const int Offset = 16 ;
  _cycles  = 0 ;
  _inputs  = inputs ;
  _outputs = outputs ;
  const int n = 2 * Offset + (inputs+1) * (outputs+1) * Flit::NUM_FLIT_TYPES ;
  _event = new int [ n ] ;
  for ( int i = 0 ; i < n ; i++ ) {
	_event[i] = 0 ;
  }
  _event += Offset ;
}

int SwitchMonitor::index( int input, int output, int flitType ) const {
  return flitType + Flit::NUM_FLIT_TYPES * ( output + _outputs * input ) ;
}

void SwitchMonitor::cycle() {
  _cycles++ ;
}

void SwitchMonitor::traversal( int input, int output, Flit* flit ) {
  _event[ index( input, output, flit->type) ]++ ;
}

ostream& operator<<( ostream& os, const SwitchMonitor& obj ) {
  for ( int i = 0 ; i < obj._inputs ; i++ ) {
    for ( int o = 0 ; o < obj._outputs ; o++) {
      os << "[" << i << " -> " << o << "] " ;
      for ( int f = 0 ; f < Flit::NUM_FLIT_TYPES ; f++ ) {
	os << f << ":" << obj._event[ obj.index(i,o,f)] << " " ;
      }
      os << endl ;
    }
  }
  return os ;
}

// ----------------------------------------------------------------------
//
//   Flit Buffer Monitor
//
// ----------------------------------------------------------------------
BufferMonitor::BufferMonitor( int inputs ) {
  // something is stomping on the arrays, so padding is applied
  const int Offset = 16 ;
  _cycles = 0 ;
  _inputs = inputs ;

  const int n = 2*Offset + 4 * inputs  * Flit::NUM_FLIT_TYPES ;
  _reads  = new int [ n ] ;
  _writes = new int [ n ] ;
  for ( int i = 0 ; i < n ; i++ ) {
    _reads[i]  = 0 ; 
    _writes[i] = 0 ;
  }
  _reads += Offset ;
  _writes += Offset ;
}

int BufferMonitor::index( int input, int flitType ) const {
  if ( input < 0 || input > _inputs ) 
    cerr << "ERROR: input out of range in BufferMonitor" << endl ;
  if ( flitType < 0 || flitType> Flit::NUM_FLIT_TYPES ) 
    cerr << "ERROR: flitType out of range in flitType" << endl ;
  return flitType + Flit::NUM_FLIT_TYPES * input ;
}

void BufferMonitor::cycle() {
  _cycles++ ;
}

void BufferMonitor::write( int input, Flit* flit ) {
  _writes[ index(input, flit->type) ]++ ;
}

void BufferMonitor::read( int input, Flit* flit ) {
  _reads[ index(input, flit->type) ]++ ;
}

ostream& operator<<( ostream& os, const BufferMonitor& obj ) {
  for ( int i = 0 ; i < obj._inputs ; i++ ) {
    os << "[ " << i << " ] " ;
    for ( int f = 0 ; f < Flit::NUM_FLIT_TYPES ; f++ ) {
      os << "Type=" << f
	 << ":(R#" << obj._reads[ obj.index( i, f) ]  << ","
	 << "W#" << obj._writes[ obj.index( i, f) ] << ")" << " " ;
    }
    os << endl ;
  }
  return os ;
}

